PATH=$PATH:/usr/share/eole/sbin
