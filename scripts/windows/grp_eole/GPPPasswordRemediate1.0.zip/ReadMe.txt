SDM Software GP Preference Password Remediation Tool 1.0
August 2015
Developed/distributed exclusively by SDM Software, Inc. (https://sdmsoftware.com).

Pre-requisites
--------------

- .Net Framework 4.0 (full)
- MS Group Policy Management Console (GPMC) installed
- Windows 7, 8.x, 2008-R2 and 2012+

Functional Overview
-------------------
This utility is meant to remediate the "cpassword" entries found in certain GP Preference policy areas. The issue is described in detail in Microsoft Security Bulletin MS14-025 (https://support.microsoft.com/en-us/kb/2962486). This utility performs the following functions:

1. Scans all GPOs in an AD domain to find non-empty cpassword entries within GP Preference settings--lists those entries in the grid view.(Requires read permissions on all GPOs)
2. Allows you to right-click one or more entries and remediate those cpassword entries within the GPO's SYSVOL storage. Remediation entails removing the cpassword attribute completely from the XML that defines a setting and incrementing the GPO's version number appropriately. (Requires write permissions on any remediated GPOs)
3. Prior to remediation, the utility will perform a GPMC backup of all selected GPOs into a folder under %public%\documents\SDM Software\GPOBackups


Cached GPP Passwords
--------------------
It should be noted that GP Preferences caches it's settings files on clients receiving those settings, under the %appdata% (per-user) and %programdata% (per-computer). This includes any cpassword values that were delivered via a GPO. This makes each machine that has received one of these policies vulnerable as well. As a result, this utility will increment the GPO version, forcing the client to update it's cached GP Preference file, containing the vulnerable cpassword entries, and remove them just as they've been removed from within SYSVOL. 






NOTE: This application is presented as-is with no warranty as to it's function. This application will make changes to your GPOs, as highlighted above. By running this application, you accept these terms and the risks associated with making GPO changes. Please note that we attempt to back up your GPOs before remediating CPassword entries, but if those backups are not successful, you should have your own backups on hand in the event that a change needs to be rolled back.