WMI Filter Validation Utility 1.2
by SDM Software, Inc. (c) 2020, All rights reserved.
Software is offered as-is.

To install this utility, copy the two files included in this zip to a folder on your local hard drive. 

Execute the WMIFTest.exe file to run the utility.